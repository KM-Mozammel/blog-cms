<?php

function not_logged_in_action(){
    if(!isset($_SESSION['id'])){
        set_message("You must log in to go Dashboard,<br> Please Contact to your administrator.");
        header("Location: index.php");
        die();
    }   
}

function set_message($message){
    {
        $_SESSION['message'] = $message;
    }
}

function get_message(){
    if(isset($_SESSION['message'])){
        echo "<p>". $_SESSION['message']. "</p>";
        unset($_SESSION['message']);
    }
}