<?php
    $connect = mysqli_connect("localhost", "cms", "", "cms");

    if (mysqli_connect_errno()) {
        exit("Failed to connect to MySQL: " . mysqli_connect_error());
    }

    // $dsn = 'mysql:dbname=cms;host=127.0.0.1';
    // $user = 'cms';
    // $password = '';

    // try {
    //     $dbh = new PDO($dsn, $user, $password);
    // } catch (PDOException $e) {
    //     echo 'Connection failed: ' . $e->getMessage();
    //     exit();
    // }

